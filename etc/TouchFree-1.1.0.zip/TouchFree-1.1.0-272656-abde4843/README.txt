===== TouchFree =====


=== Overview ===

Ultraleap's TouchFree is a Screen Control app for Windows that enables touchless gesture control to your existing Windows UI, via Ultraleap's hand tracking technology. 

It provides a customizable cursor overlay which sits on top of your user interface, translating mid-air hand movements into on-screen touch events for selection, drag and hover.


=== Requirements ===

- Windows 10, 64-bit.
- Ultraleap hand tracking module (Stereo IR 170 Camera Module or Leap Motion Controller)
- Leap Motion Service installed (V4, "Orion" or later)


=== Getting started ===

- Set up your display/kiosk to be a comfortable height and distance from you.
- Connect and mount your Ultraleap hand tracking module (refer to Setup guides for camera placement recommendations)
- Ensure Leap Motion (V4 or later) service is installed and running on your machine: https://www2.leapmotion.com/v4-developer-beta-windows
- In the Leap Motion Control panel, open the Diagnostic Visualizer to check the hand is being tracked.
    - You may need to click "Reverse Orientation" if the camera orientation is incorrect. The wrist should be coming from the bottom of the image.
    - Once you are satisfied with hand tracking in the visualiser, ensure you disable "Auto-orient Tracking" in the Leap Control Panel.
- Run the TouchFree.exe included with this build. The program will start, and a transparent overlay will be shown wish a setup wizard.
    - You should make sure TouchFree.exe has the same or higher privilege level as the application it will be interacting with. For example, if your target app is set to "Run As Administrator", TouchFree.exe will need to be "Run As Administrator" as well. TouchFree cannot send input events to the target app if TouchFree is run with a lower privilege level.

You will now need to configure TouchFree for your screen size and Leap position.
It is best if you have a ruler or tape measure to hand to check the measurements that will be taken in the following step.

=== Setting up TouchFree ===

== Selecting the correct screen ==

TouchFree will automatically run on the "main display".
If you have more than 1 monitor connected, either unplug them, or set the monitor you want to test with to be your "Main Display" in Windows Display Settings.


== Quick Setup ==

By default, the setup wizard will load. If it is not open, ensure TouchFree is focussed and press 'C' to open the setup wizard.

In the first instance, perform a Quick Setup where you will be given instructions to follow to calibrate the screen and Leap.
    Place your finger as close to the screen as you can and in the centre of the markers.

Once complete, you may test the calibration of the cursor. If this is not sufficient, you can re-run the Quick Setup, or move to Manual Setup to adjust.


== Manual Setup ==

If you have measurements of the screen and distance to the Leap or have run Quick Setup and need to slightly adjust values, use Manual Setup from the Setup Wizard ('C').

This screen provides various values which are default and you can adjust these values by typing in the text boxes.

Descriptions of each value accompany them, more detailed descriptions can be found in this document below.


== Configuring screen size & tilt and Leap position & tilt ==

TouchFree requires knowledge about the height of your screen, as well as the Leap position relative to the bottom of the screen pixel area.

The config parameters are stored in the TouchlessConfig.json file which can be found at %userprofile%/AppData/LocalLow/Ultraleap/TouchFree/TouchlessConfig.json.
If you modify this file, click the TouchFree icon in the taskbar to focus the application then press the 'R' key to load the values.
All values denoted with "cm" are in centimetres. Values with "D" are in degrees.

= Screen size =

This is the distance in meters between the top of the pixels and bottom of the pixels of the screen itself.
Do not measure the bezel or outside of the pixel area of the screen.
The bottom of the screen is relative to the bottom of the pixel area.

= Screen tilt =

For a rotated screen, set the "ScreenRotationD" property.
0 degrees is a vertical screen facing towards the user.
90 degrees is a horizontal screen facing the ceiling.

= Leap position =

For the Leap position, set the "LeapPositionRelativeToScreenBottomM" property.
Spatial axis for the Leap position relative to the centre of the bottom of the screen (pixel area, not the bezel or any other edge):
    X is right and left (positive right, negative left)
    Y is up and down (positive up, negative down)
    Z is towards or away from screen (positive toward the screen, negative away from screen)

= Leap tilt =

To tilt the tracking camera, change the "LeapRotationD" X property:

 - a positive X value will tilt the Leap towards the screen.
 - a negative X value will tilt the Leap away from the screen.

For example, a bottom mount at 30 degrees tilted towards the screen:

    "LeapRotationD": {
        "x": 30.0,
        "y": 0.0,
        "z": 0.0
    },

And a top mount at 20 degrees tilted away from the screen:

    "LeapRotationD": {
        "x": -20.0,
        "y": 0.0,
        "z": 180.0
    },

=== Using TouchFree ===

It is best to use some content design for touch screens, specifically Quick Service Restaurant type interfaces (rather than Windows desktop!).

- Hold your hand up in front of your monitor. You will see a cursor projected onto the screen.
- Move your hand forwards towards the screen. A circle will appear and begin to shrink inwards.
- Once the circle touches the centre, the dot will shrink and a "touch event" will register with Windows.

To quit, right-click the TouchFree icon in the taskbar and "Close window".


=== Configuring the Call to Interact ===

The call to interact (CTI) feature is intended to help on-board users by displaying a static image or a video of how to begin using the display.
The CTI graphic resolution should match the screen you will be using TouchFree with. For example, a standard portrait screen resolution is 1080x1920, so your CTI graphic should be this size too.
The CTI graphic will cover the whole screen but can have transparent areas so the graphic doesn't cover the entire content. In this way, the CTI graphic will overlay existing content to allow certain areas of the screen to be targeted.

== Step one, get an image or video ==

Image requirements:
    - It must be a .png image.
    - It should be the same aspect ratio as the screen you will be using TouchFree with.
    - Any area of the screen you do not want the image to cover should be fully transparent.

Video requirements:
    - It must be a VP8 encoded .webm video or an opaque .mp4.
    - It should be the same aspect ratio as the screen you will be using TouchFree with.
	- Any area of the screen you do not want the image to cover should be fully transparent.

== Step two, put it in the correct place ==

- Open the folder where the TouchFree executable file is (TouchFree.exe).
- Open the TouchFree_Data folder.
- Open StreamingAssets. If you do not see a StreamingAssets folder here, create one.
- In StreamingAssets, create a CallToInteract folder. It is important that this is spelled correctly: TouchFree_Data/StreamingAssets/CallToInteract/
- Drop your CTI asset into this folder and it will appear in the dropdown

== Step three, enable the CTI ==

Open the settings screen via the setup wizard (press 'C'), scroll to the bottom of the screen and enable the CTI, set the correct file from the dropdown list.
Timings can also be set here.

== CTI Config ==

Additionally, there is a config file for CTI parameters such as timeouts between showing the CTI graphic and enabling/disabling the system.
The config file can be found at %userprofile%/AppData/LocalLow/Ultraleap/TouchFree/CallToInteractSettings.json.
See "List of CallToInteractSettings.json properties" below for details of all the parameters.

=== Appendix ===

== List of TouchlessConfig.json properties ==

After modifying the TouchlessConfig.json file directly, click the TouchFree icon in the taskbar to focus the application then press the 'R' key to load the values.

ScreenHeightM                           -   Height of the pixel area of the screen. If the pixels of the display do not reach the edge of the monitor, measure just from the bottom to the top of the pixels (do not include a bezel or anything else). Positive number.

LeapPositionRelativeToScreenBottomM     -   Position of the center of your tracking module relative to the bottom of the pixel area of your screen.
                                                X is right and left (positive right, negative left)
                                                Y is up and down (positive up, negative down)
                                                Z is towards or away from screen (positive toward the screen, negative away from screen)

LeapRotationD                           -   Rotation of your tracking module.
                                                If bottom mounted:
                                                    X is towards/away from the screen (Pitch) - positive tilts towards the screen, negative tilts away from the screen.
                                                    Y is spinning from above (Yaw) - positive is clockwise, negative is counter-clockwise.
                                                    Z is flip parallel to the screen (Roll) - for bottom mounting, this should be set to 0.0.
                                                If top mounted:
                                                    X is towards/away from the screen (Pitch) - positive tilts towards the screen, negative tilts away from the screen.
                                                    Y is spinning from above (Yaw) - positive is still clockwise, negative is counter-clockwise.
                                                    Z is flip parallel to the screen (Roll) - for top mounting, this should be set to 180.0.

ScreenRotationD                         -   Tilt angle of the screen (0 is vertical with screen facing outward, 90 is horizontal with screen facing directly up to ceiling)

Example structure:

{
    "ScreenHeightM": 0.33,
    "LeapPositionRelativeToScreenBottomM": {
        "x": 0.0,
        "y": -0.20,
        "z": -0.22
    },
    "LeapRotationD": {
        "x": 0.0,
        "y": 0.0,
        "z": 0.0
    },
    "ScreenRotationD": 0.0,
}

== List of Settings.json properties ==

The settings parameters are stored in the Settings.json file which can be found at %userprofile%/AppData/LocalLow/Ultraleap/TouchFree/Settings.json.


CursorRingColor                         -   Hex colour value (RGBA) for the ring of the ring cursor.
CursorRingOpacity                       -   Opacity for the ring of the ring cursor.
CursorDotFillColor                      -   Hex colour value (RGBA) for the fill of the dot cursor.
CursorDotFillOpacity                    -   Opacity for the fill of the dot cursor.
CursorDotBorderColor                    -   Hex colour value (RGBA) for the border of the dot cursor.
CursorDotBorderOpacity                  -   Opacity for the border of the dot cursor.
CursorColourPreset                      -   Current colour preset index for the cursor.
CursorDotSizeM                          -   Size of the cursor dot in physical meters as it will appear on the screen.
CursorRingMaxScale                      -   How big the ring will be when the user’s hand is at distance specified in CursorMaxRingScaleAtDistanceM.
CursorMaxRingScaleAtDistanceM           -   The distance the user’s hand must be so that the ring is at max scale and will begin shrinking inwards.
UseScrollingOrDragging                  -   Whether to allow the cursor to do a drag command or to instant-click. True will allow events down-hold-drag-up and down-hold-up. False will "instant-click" on screen but instantly doing down-up events.
InteractionSelection					-	The index for the type of interaction the user is expected to use.
ShowSetupScreenOnStartup				-	Should the setup screen appear on start-up of the application?
DeadzoneRadius							-	The size of the deadzone for cursor stabilisation.
CursorVerticalOffset					-   Used to determine vertical offset so the user can see the cursor while interacting.
SendHoverEvents                         -   Used to toggle if Windows Hover events are sent while moving the cursor. This can cause touch screens to fail to work.
HoverCursorStartTimeS                   -   The time required for a user to hold their hand still until the Hover & Hold cursor starts filling
HoverCursorCompleteTimeS                -   The time it takes for the Hover & Hold cursor to fill and pperform a Touch event.
TouchPlaneDistanceFromScreenM           -   The distance from the screen that the Air Push interaction will force an interaction 


Example structure:

{
    "CursorRingColor": "#000000",
    "CursorRingOpacity": 1.0,
    "CursorDotFillColor": "#000000",
    "CursorDotFillOpacity": 1.0,
    "CursorDotBorderColor": "#FFFFFF",
    "CursorDotBorderOpacity": 0.8,
    "CursorColorPreset": 3,
    "CursorDotSizeM": 0.008,
    "CursorRingMaxScale": 2.0,
    "CursorMaxRingScaleAtDistanceM": 0.1,
    "UseScrollingOrDragging": false,
    "InteractionSelection": 2,
    "ShowSetupScreenOnStartup": true,
    "DeadzoneRadius": 0.003,
    "CursorVerticalOffset": 0.0,
    "SendHoverEvents": false,
    "HoverCursorStartTimeS": 0.5,
    "HoverCursorCompleteTimeS": 0.6,
    "TouchPlaneDistanceFromScreenM": 0.05
}

== List of CallToInteractSettings.json properties ==

The settings parameters are stored in the Settings.json file which can be found at %userprofile%/AppData/LocalLow/Ultraleap/TouchFree/Settings.json.

Enabled                      -   Whether to allow the call to interact to display.
ShowTimeAfterNoHandPresent   -   The time it takes for the call to interact graphic to be shown after no hands are detected.
HideTimeAfterHandPresent     -   The time it takes for the call to interact graphic to disappear after a hand as been detected.
CurrentFileName				 -	 The file you would like to be displayed.
hideType                     -   An index for the type of interaction required to close the CTI

Example structure:

{
    "Enabled": false,
    "ShowTimeAfterNoHandPresent": 10.0,
    "HideTimeAfterHandPresent": 0.5,
    "CurrentFileName": "1 Push in mid-air to start.mp4",
    "hideType": 1
}